
exports.index = function( req, res ){
    console.log( 'routing', req.body.port);
    res.render( 'spice', {port: req.body.port });
};
