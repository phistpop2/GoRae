
var SPICE_URL = "http://211.189.20.71:8095";


setOnContext = function( selector, vmBox ){
    $.contextMenu({
        selector: selector,
        callback: function(key, options) {
            //var m = "clicked: " + key;
            //window.console && console.log(m) || alert(m);

            //$(selector).blur();/
            switch( key ){
                case "run":
                    vmBox.setState("run",
                    function(data){
                        console.log( 'run success', data );
                        vmBox.reload();
                    },
                    function(data){
                        console.log( 'run error', data );
                    });
                    break;
                case "stop":
                    vmBox.setState("stop",
                        function(data){
                            console.log( 'stop success', data );
                            vmBox.reload();
                        },
                        function(data){
                            console.log( 'stop error', data );
                        });
                    break;
                case "delete":
                    $.ajax({
                        url:'/vms/delete',
                        type:"post",
                        data: { uuid: vmBox.getUUID() },
                        datatype: 'json',
                        success: function( data ){
                            vmBox.clear();
                        },
                        error:function(){
                            console.log( "delete err")
                        }
                    });
                    break;
                case "view":

                    var form = document.createElement("form");
                    form.setAttribute("method", "post");
                    form.setAttribute("action", "/vms/view");
                    form.setAttribute("target", "/vms/view");

                    var jForm = $(form);

                    var input = document.createElement("input");
                    input.type = "hidden";
                    input.name = "uuid";
                    input.value = vmBox.getUUID();
                    $(input).appendTo(jForm);
                    //.appendChild(input);



                    //alert("view!"+input.value);
                    hWndHelp = window.open('', '/vms/view', 'width=1188, height=840, resizable= no');
                    hWndHelp.focus();


                    jForm.appendTo('body').submit();
                    //alert("view!2"+input.value);
                    try {
                       // document.body.removeChild(form);
                    }catch( e ){
                        console.log( "removeChild", e );
                    }
                    break;
            }
        },
        items: {
            "run": {name: "Run", icon: ""},
            "stop": {name: "Stop", icon: ""},
            "delete": {name: "Delete", icon: ""},
            "view": {name: "View", icon: ""}
/*            "sep1": "---------",
            "quit": {name: "Quit", icon: "quit"}*/
        }
    });
}

VmBox = function( $container, uuid ){


    console.log( 'virtual box', $container, uuid );
    var json;
    var currentState = "stop";

    function coloring( state ){
        switch( state ){
            case "running":
                $container.find('.vm-box').switchClass( "panel-default inactbox", "panel-primary actbox", 500, "easeInOutQuad");
                break;
            case "stopped":
                $container.find('.vm-box').switchClass( "panel-default inactbox", "panel-info inactbox", 500, "easeInOutQuad");
                break;
            default:
                break;
        }
    }


    function init(){
        var vmbox1 = new ajaxLoader($container.find('.panel-heading'), {classOveride: 'blue-loader'});
        console.log( "uuid", uuid );
        $.ajax({
            url: '/vms/detail',
            type:'post',
            datatype :'json',
            data : { uuid : uuid },
            success: function( data ){
                //set layout
                json = data;
                console.log( "Virtaul zones info:", data );
                if( vmbox1 ) vmbox1.remove();


                currentState = data.state;
                coloring( data.state );

                $container.find('.panel-heading').text(data.alias);
                $container.find('.state').text( data.state );
                $container.find('.cpu').text( data.vcpus + " core" );
                $container.find('.ram').text( data.ram + " MB" );

                if( data.disks.length > 0 ){
                    $container.find('.storage').text( data.disks[0].size + " MB" );
                }

                $container.on('click', function(event){
                    $container.trigger('contextmenu');

                });

            },
            error:function( err ){
                console.log( "error", err  );
                $container.find('.panel-heading').text('loading fail');
                if( vmbox1 ) vmbox1.remove();
            }
        });
    }
    init();

    function setState( state, callback, error ){
        var url = null;

        switch( state ){
            case "run":
                url = '/vms/start';
                break;
            case "stop":
                url = '/vms/stop';
                break;
        }

        if( url ) {
            var vmbox1 = new ajaxLoader($container.find('.panel-heading'), {classOveride: 'blue-loader'});
            $.ajax({
                url: url,
                type: 'post',
                datatype: 'json',
                data: { uuid: uuid },
                success: function(data){
                    if( vmbox1 ) vmbox1.remove();
                    callback(data);
                },
                error: error
            });
        }
    }

    return{
        setState : setState,
        getPort : function(){
            return 27012;
        },
        getUUID: function(){
            return uuid;
        },
        clear: function(){
            $container.remove();
        },
        reload : function() {
            init();
        }
    }
};


VmDialog = function( $container, $opener, obj ){
    var cbOpen = null;
    var cbSuccess = null;
    var cbClose = null;

    $container.draggable();

    if( obj ){
        cbOpen = obj.open;
        cbClose = obj.close;
        cbSuccess = obj.success;
    }

    function close(){
        if (cbOpen){
            cbOpen();
        }
        console.log( 'vmd close ');
        $container.css({
            top : '0',
            left : '0'

        });
    }
    function success(){
        console.log( "success");
        if (cbSuccess){
            console.log( "success2");
            cbSuccess($container.find( '.modal-content'));
        }

    }
    function open(){
        if( cbClose ){
            cbClose();
        }
    }
    if( $container ) {
        $container.find('.vd-close').on('click', function () {
            //close();
        });
        $container.find('.vd-gen').on('click', function () {
            console.log( "gen")
            var alias = $('#pc-name').val();
            var os = $('#dropdownMenu1').val();
            var vcpus = $('#sl1').val();
            var ram = $('#sl2').val();

            if( os && os.length > 0 ){
                console.log( "create vm", "alias:"+alias+" os:"+os+" vcpu:"+vcpus+" "+ram );

                var val = {
                    alias : alias,
                    os : os,
                    vcpus : vcpus,
                    ram : ram*512
                }

                $.ajax({
                    url:'/vms/create',
                    type:"post",
                    data: val,
                    datatype: 'json',
                    success: function( data ){
                        console.log( "createvm ok", data )
                        var $vm = $(
                                '<div id="vm-'+data.uuid+'" class="vm-cont col-lg-4">'+
                                '<div class="panel panel-default vm-box inactbox">'+
                                '<div class="panel-heading">'+
                                'loading...'+
                                '</div>'+
                                '<div class="panel-body" style="overflow: auto">'+
                                '<div class="info-conatiner">'+
                                '<div class="row vm-info state">'+
                                '</div>'+
                                '<div class="row vm-info cpu">'+
                                '</div>'+
                                '<div class="row vm-info ram">'+
                                '</div>'+
                                '<div class="row vm-info storage">'+
                                '</div>'+
                                '</div>'+
                                '</div>'+
                                '</div>'+
                                '</div>'
                        )
                        setOnContext( '#vm-'+data.uuid, new VmBox( $vm, data.uuid ) );
                        $('#cont-vm-add').before( $vm );
                    },
                    error:function(){
                        console.log( "insert err")
                    }
                });

                /*
                $.ajax({
                    url: url,
                    type:'post',
                    datatype :'json',
                    data : data,
                    success: function( data ){
                        console.log( "adsf", data );

                        var val = {
                            username: "user1",
                            password: "pass",
                            uuid: data.uuid
                        }
                        var muuid = data.uuid;

                        console.log( "make########", data );

                        $.ajax({
                            url:'/insert',
                            type:"post",
                            data: val,
                            datatype: 'json',
                            success: function( data ){
                                console.log( "insert ok")
                                var $vm = $(
                                        '<div id="vm-'+muuid+'" class="vm-cont col-lg-4">'+
                                        '<div class="panel panel-default vm-box inactbox">'+
                                        '<div class="panel-heading">'+
                                        'loading...'+
                                        '</div>'+
                                        '<div class="panel-body" style="overflow: auto">'+
                                        '<div class="info-conatiner">'+
                                        '<div class="row vm-info state">'+
                                        '</div>'+
                                        '<div class="row vm-info cpu">'+
                                        '</div>'+
                                        '<div class="row vm-info ram">'+
                                        '</div>'+
                                        '<div class="row vm-info storage">'+
                                        '</div>'+
                                        '</div>'+
                                        '</div>'+
                                        '</div>'+
                                        '</div>'
                                )
                                setOnContext( '#vm-'+muuid, new VmBox( $vm, muuid ) );
                                $('#cont-vm-add').before( $vm );
                            },
                            error:function(){
                                console.log( "insert err")
                            }
                        });
                    },
                    error:function( err ){
                        console.log( "err");
                    }

                });*/

            }
            success();
        });
        $container.on('hidden.bs.modal', function(){
            close();
        });
        $container.on('show.bs.modal', function(){
            $('.well .slider').css({width:"100%"});
            $('.tooltip.top').css({
                marginTop:"-20px"
            });
            $('#sl1').slider('setValue', 1 );
            $('#sl2').slider('setValue', 1 );
        });
    }
    if( $opener ){
        $opener.on('click', function(){
            open();
        });
    }
    return {
        close : function(data){
            close();

        },
        open : function(data){

        },
        success :function(data){

        }
    }
};


$(document).ready( function(){

    var dialog, form;
    dialog = new VmDialog( $("#new-vm-dialog"), $('#btn-vm-add'), {
        open: function(){
        },
        close : function(){
        },
        success: function($container){
            //box1 = new ajaxLoader($container, {classOveride: 'blue-loader'});
        }
    });



    function clearProgress(){
        dialog.data('callback').valid();
        dialog.dialog( "close" );
    }



    function listup( objs ){
        var vmsContainter = $('.vms-container');
        objs.forEach( function( value, index ){
            console.log( "value", value.uuid );
            var $vm = $(
                '<div id="vm-'+value.uuid+'" class="vm-cont col-lg-4">'+
                    '<div class="panel panel-default vm-box inactbox">'+
                        '<div class="panel-heading">'+
                        'loading...'+
                        '</div>'+
                        '<div class="panel-body" style="overflow: auto">'+
                            '<div class="info-conatiner">'+
                                '<div class="row vm-info state">'+
                                '</div>'+
                                '<div class="row vm-info cpu">'+
                                '</div>'+
                                '<div class="row vm-info ram">'+
                                '</div>'+
                                '<div class="row vm-info storage">'+
                                '</div>'+
                            '</div>'+
                        '</div>'+
                    '</div>'+
                '</div>'
            )
            setOnContext( '#vm-'+value.uuid, new VmBox( $vm, value.uuid ) );
            $('#cont-vm-add').before( $vm );
        });
    }

    function loadVirtualMachine(){
        var progressBar = new ajaxLoader($('.container'), {classOveride: 'blue-loader', overWidth:'100%', overHeight:'100%'});
        $.ajax({
            url:'/vms/getvms',
            type:"post",
            datatype: 'json',
            success: function( data ){
                console.log( "vm data", data );
                listup( data.vms );
                if( progressBar ) progressBar.remove();
            },
            error:function(){
                if( progressBar ) progressBar.remove();
            }
        });
    }
    loadVirtualMachine();

    $("#btn-vm-add")
    .on('focus', function(){
        this.blur();
    })
    .on('click', function(){
        $("#new-vm-dialog").show();
    });


    $('.dropdown-menu li a').click(function(){
        $('#dropdownMenu1').text( $(this).text()+' ').append( $("<span class='caret'></span>"));
        $('#dropdownMenu1').val( $(this).data('value') );
    });


    $('#sl1').slider({
        formater: function(value) {
            return value + ' Core';
        }
    });
    $('#sl2').slider({
        formater: function(value) {
            return value*512 + ' MB';
        }
    });

});
