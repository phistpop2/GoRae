/**
 * Created by sungho on 2014-07-22.
 */


var express = require('express'),
    app = module.exports = express(),
    //app = module.exports = express.createServer(),
    mongoose = require('mongoose'),
    mongoStore = require('connect-mongodb'),
    db,
    Document,
    User,
    Books,
    Settings = { development: {}, test: {}, production: {} };

var http = require('http');
var path = require('path');
var jquery = require('jquery');
var restify= require('restify');
var urlencode = require('urlencode');
var fs = require('fs');
var crypto = require('crypto');
var exec  = require('child_process').exec;
var portscan = require('portscanner');

var MAIN_PORT = 3033;
var MAIN_DB = "mongodb://localhost:27017/bookfodb";

var SPICE_AUTH = "1012";
var SPICE_ADMIN = "admin";

var zones = restify.createJsonClient({
    url: 'http://211.189.20.71:8095'
});
zones.basicAuth(SPICE_ADMIN, SPICE_AUTH);


// Converts a database connection URI string to
// the format connect-mongodb expects
function mongoStoreConnectionArgs() {

    return { dbname: db.db.databaseName,
        host: db.db.serverConfig.host,
        port: db.db.serverConfig.port,
        username: db.user,
        password: db.pass };
}


// configure
app.set('port', MAIN_PORT);
app.set('db-uri', MAIN_DB);

db = (mongoose.connect(app.set('db-uri')));
if( !db.db ) db = db.connections[0];


app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

var bodyParser = require('body-parser');

var cookieParser = require('cookie-parser');
var logger = require( 'morgan' );
var methodOverride = require( 'method-override' );
var session = require('express-session');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded( {extended:true}));
app.use(cookieParser('optional secret string'));
//app.use(express.cookieDecoder());
app.use(session({
    secret: 'keyboard cat',
    store: mongoStore(mongoStoreConnectionArgs()),
    resave: true,
    saveUninitialized: true
}));
//app.use(express.logger({ format: '\x1b[1m:method\x1b[0m \x1b[33m:url\x1b[0m :response-time ms' }));
app.use(logger('dev'));
app.use(methodOverride());
//app.use(express.compiler({ src: __dirname + '/public', enable: ['less'] }));
app.use(require('stylus').middleware(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, '/')));



app.User = User = require('./models.js').User(db);
app.Books = Books = require('./models.js').Books(db);


app.post('/users/signup', function( req, res){
    if( req.body && req.body.username && req.body.password ){
        var json = {
            username : req.body.username,
            password : req.body.password
        }
        var user = new User( json );
        user.saltPassword( req.body.password );
        user.makeAccessToken();
        user.save( function( err, room ){
            if( err ){
                res.status( 522).send( { msg:err } );
            }else{
                res.send( {msg:"sign up", token:user.token});
            }
        });
    }else{
        res.status(521).send( {msg:"request sign up : wrong data"} );
    }
});

app.post('/users/signin', function( req, res ){
    if( req.body && req.body.username && req.body.password ){
        User.findOne({username:req.body.username}, function(err, user){
            if( err ) {
                res.status( 532 ).send( {msg:"server error"} );
            } else if( !user ) {
                res.status( 533 ).send( {msg:"could not find user id"} );
            } else if (user && user.authenticate(req.body.password)) {
                res.send( {msg:"sign in", token:user.token});
            } else {
                res.status( 534 ).send( {msg:"auth fail"} );
            }
        });
    }else{
        res.status(531).send( {msg:"request sign in : wrong data"} );
    }
});

app.get('/book/:token', function(req, res){
    if( req.params.token ){
        Books.find( {owner : req.params.token}, function( err, books ){
            if( err ){
                res.status(540).send( {msg:err} );
            }else {
                console.log( books, "<<<<<<<");
                res.send({msg:"book get", items:books});
            }
        });
    }
});

app.post('/book/:token', function(req, res ){
    if( req.params.token && req.body ){
        var json = {
            owner : req.params.token,
            isbn : req.body.isbn,
            item : req.body
        }

        var book = new Books( json );

        book.save( function( err, room ){
            if( err ){
                res.status( 541).send( { msg:err } );
            }else{
                res.send( {msg:"book reg", info:room.id});
            }
        });
    }
});
app.delete('/book/:isbn', function(req, res){
    if( req.params.isbn ){
        console.log( urlencode.decode( req.params.isbn ) ) ;
        Books.remove({
                owner:req.headers.access_token,
                isbn:urlencode.decode( req.params.isbn )
            },
            function(err){
                if( err ){
                    res.status(542).send({msg:err});
                }else{
                    res.send({msg:"book del"});
                }
        });
    }
});

if (!module.parent) {
    http.createServer(app).listen(app.set('port'), function(){
        console.log('Express server listening on port ' + app.set('port'));
    });
}