/**
 * Created by sungho on 2014-07-21.
 */
var mongoose = require('mongoose'),
    crypto = require('crypto');

var Schema = mongoose.Schema;
var uuid = require('node-uuid');

var Document = new Schema(
    {
        properties: ['title', 'data', 'tags', 'user_id'],

        indexes: [
            'title',
            'user_id'
        ]

//        getters: {
//            id: function() {
//                return this._id.toHexString();
//            }
//        }
    }
);


var Books = new Schema(
    {
        owner:String,
        isbn:String,
        item:{
            title:String,
            link:String,
            image:String,
            author:String,
            price:String,
            discount:String,
            publisher:String,
            pubdate:String,
            isbn:String,
            description:String
        }
    }
)

var User = new Schema(
    {
        username : { type : String, unique: true },
        password : { type : String },
        salt : {type:String},
        level : {type : Number },
        vms : [{uuid:String}],
        token :{type:String, unique:true}


        // hashed_password : { type : String,  get : getuserid }
        //password : { type : String, get : getPassword, set : setPassword }
        /*
        properties: ['email', 'hashed_password', 'salt'],

        indexes: [
            [{ email: 1 }, { unique: true }]
        ],

        getters: {
            id: function() {
                return this._id.toHexString();
            },

            password: function() { return this._password; }
        },

        setters: {
            password: function(password) {
                this._password = password;
                this.salt = this.makeSalt();
                this.hashed_password = this.encryptPassword(password);
            }
        },
        */

    }
);
User.path('username').get( function(v){
    return v;
});

User.methods.saltPassword = function(v){
    //this._password = v;
    this.salt = this.makeSalt();
    this.password = this.encryptPassword(v);
};


User.methods.authenticate = function(plainText) {
    var ps1 = this.encryptPassword(plainText);
    console.log('ps1', ps1);
    console.log('ps2', this.password);
    return ps1 === this.password;
};
User.methods.makeSalt = function() {
        return Math.round((new Date().valueOf() * Math.random())) + '';
};
User.methods.encryptPassword = function(password) {
    return crypto.createHmac('sha1', this.salt).update(password).digest('hex');
};



User.methods.makeAccessToken =  function(){
    this.token = uuid.v4();
};

User.methods.isValid = function() {
        // TODO: Better validation
    return this.username && this.username.length > 0 && this.username.length < 255
        && this.password && this.password.length > 0 && this.password.length < 255;
}
User.methods.triggerSave = function(okFn, failedFn) {
    if (this.isValid()) {
        this.save(okFn);
    } else {
        failedFn();
    }
}



mongoose.model('Document', Document);

mongoose.model('User', User );
mongoose.model('Books', Books );

exports.User = function(db) {
    return db.model('User');
};
exports.Books = function(db) {
    return db.model('Books');
}

exports.Document = function(db) {
    return db.model('Document');
};