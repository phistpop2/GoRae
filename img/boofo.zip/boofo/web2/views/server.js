/**
 * Created by sungho on 2014-07-22.
 */
var express = require('express'),
    app = module.exports = express(),
//app = module.exports = express.createServer(),
    mongoose = require('mongoose'),
    mongoStore = require('connect-mongodb'),
    db,
    Document,
    User,
    Settings = { development: {}, test: {}, production: {} };

var http = require('http');
var path = require('path');
var jquery = require('jquery');
var restify= require('restify');
var fs = require('fs');
var crypto = require('crypto');
var exec  = require('child_process').exec;
var portscan = require('portscanner');

var SPICE_ADMIN = "admin";
var SPICE_AUTH = "1012";

var zones = restify.createJsonClient({
    url: 'http://211.189.20.71:8095'
});
zones.basicAuth(SPICE_ADMIN, SPICE_AUTH);


// Converts a database connection URI string to
// the format connect-mongodb expects
function mongoStoreConnectionArgs() {

    return { dbname: db.db.databaseName,
        host: db.db.serverConfig.host,
        port: db.db.serverConfig.port,
        username: db.user,
        password: db.pass };
}


// configure
app.set('port', 3000 );
app.set('db-uri', 'mongodb://localhost/spicedb');
db = (mongoose.connect(app.set('db-uri')));
if( !db.db ) db = db.connections[0];


app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

var bodyParser = require('body-parser');
var favicon = require( 'serve-favicon' );
var cookieParser = require('cookie-parser');
var logger = require( 'morgan' );
var methodOverride = require( 'method-override' );
var session = require('express-session');

//app.use(favicon());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded( {extended:true}));
app.use(cookieParser('optional secret string'));
//app.use(express.cookieDecoder());
app.use(session({
    secret: 'keyboard cat',
    store: mongoStore(mongoStoreConnectionArgs()),
    resave: true,
    saveUninitialized: true
}));
//app.use(express.logger({ format: '\x1b[1m:method\x1b[0m \x1b[33m:url\x1b[0m :response-time ms' }));
app.use(logger('dev'));
app.use(methodOverride());
//app.use(express.compiler({ src: __dirname + '/public', enable: ['less'] }));
app.use(require('stylus').middleware(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, '/')));


//app.Document = Document = require('./models.js').Document(db);
app.User = User = require('./models.js').User(db);
o







function loadUser(req, res, next) {
    console.log('a', req.session );
    if (req.session.username) {
        console.log('a')
        User.findById(req.session.username, function(user) {
            if (user) {
                req.currentUser = user;
                console.log('ab')
                next();
            } else {
                res.redirect('/sessions/new');
            }
        });
    } else {
        res.redirect('/sessions/new');
    }
}

app.get('/', loadUser, function(req, res) {
    res.redirect('/documents')
});



// Document list
app.get('/documents.:format?', loadUser, function(req, res) {
    Document.find().all(function(documents) {
        switch (req.params.format) {
            case 'json':
                res.send(documents.map(function(d) {
                    return d.__doc;
                }));
                break;

            default:
                res.render('documents/index.jade', {
                    locals: { documents: documents, currentUser: req.currentUser }
                });
        }
    });
});

app.get('/documents/:id.:format?/edit', loadUser, function(req, res) {

    Document.findById(req.params.id, function(d) {
        res.render('documents/edit.jade', {
            locals: { d: d, currentUser: req.currentUser }
        });
    });
});

app.get('/documents/new', loadUser, function(req, res) {
    res.render('documents/new.jade', {
        locals: { d: new Document(), currentUser: req.currentUser }
    });
});

// Create document
app.post('/documents.:format?', loadUser, function(req, res) {
    var d = new Document(req.body.d);
    d.save(function() {
        switch (req.params.format) {
            case 'json':
                res.send(d.__doc);
                break;

            default:
                res.redirect('/documents');
        }
    });
});

// Read document
app.get('/documents/:id.:format?', loadUser, function(req, res) {
    Document.findById(req.params.id, function(d) {
        switch (req.params.format) {
            case 'json':
                res.send(d.__doc);
                break;

            default:
                res.render('documents/show.jade', {
                    locals: { d: d, currentUser: req.currentUser }
                });
        }
    });
});

// Update document
app.put('/documents/:id.:format?', loadUser, function(req, res) {
    Document.findById(req.body.d.id, function(d) {
        d.title = req.body.d.title;
        d.data = req.body.d.data;
        d.save(function() {
            switch (req.params.format) {
                case 'json':
                    res.send(d.__doc);
                    break;

                default:
                    res.redirect('/documents');
            }
        });
    });
});

// Delete document
app.delete('/documents/:id.:format?', loadUser, function(req, res) {
    Document.findById(req.params.id, function(d) {
        d.remove(function() {
            switch (req.params.format) {
                case 'json':
                    res.send('true');
                    break;

                default:
                    res.redirect('/documents');
            }
        });
    });
});



// Users
app.get('/users/new', function(req, res) {
    res.render('users/new.jade', {
        locals: { user: new User() }
    });
});
app.post('/users/find', function(req, res){
    User.findOne({username:req.body.username}, function(err, user){
        if( err ) {
            console.log('error');
            res.send(err);
        }else{
            console.log('user');
            res.send(user);
        }

    });
});
app.post('')
app.post('/users.:format?', function(req, res) {
    var user = new User(req.body.user);
    user.saltPassword(req.body.user.password);


    function userSaved(err) {
        if( err ){
            console.log(' saved error', err);
        }else {
            switch (req.params.format) {
                case 'json':
                    res.send(user.__doc);
                    break;
                default:
                    console.log('redirect to main');
                    req.session.username = user.id;
                    res.redirect('/documents');
            }
        }
    }
    function userSaveFailed() {
        // TODO: Show error messages
        console.log('save failed');
        res.render('users/new.jade', {
            locals: { user: user }
        });
    }

    user.triggerSave(userSaved, userSaveFailed);
});



// Sessions
app.get('/sessions/new', function(req, res) {
    res.render('sessions/signin.ejs', {
        locals: { user: new User() }
        // TODO : Show detail error - req.query.sign_fail or sign_code
    });
});

// login 시도
app.post('/sessions', function(req, res) {
    User.findOne({username:req.body.user.username}, function(err, user){
        if( err ) {}
        if (user && user.authenticate(req.body.user.password)) {
            req.session.username = user.username;
            req.session.userport = {};
            res.redirect('/vms/main');
        } else {
            // TODO: Show error
            console.log('error!');
            res.redirect('/sessions/new?sign_fail=true');
        }
        console.log('show error0')
    });
});

app.delete('/sessions', loadUser, function(req, res) {
    if (req.session) {
        req.session.destroy(function() {});
    }
    res.redirect('/sessions/new');
});


// Virtual Machines (vms)
app.get('/vms/main', loadUser, function(req, res){
    console.log('main page');
    res.render('vms/main.ejs', {

    });
});
app.post('/vms/getvms', loadUser, function(req, res){
    if( req.method === 'POST' && req.body ){

        User.findOne(
            { username : req.session.username },
            function(err, obj){
                if( err ){
                    res.status(500).send(err);
                }else{
                    res.send( obj );
                }
            }
        )
    }
});
app.post('/vms/detail', loadUser, function(proxy_req, proxy_res ){
    if( proxy_req.method === 'POST' && proxy_req.body ){
        var url = "/zones/"+proxy_req.body.uuid;

        zones.get(url, function(err, req, res, obj){
            if( err ){
                proxy_res.status(500).send(err);
            }else{
                proxy_res.send(obj);
            }
        });
    }
});
app.post('/vms/start', loadUser, function(proxy_req, proxy_res ){
    if( proxy_req.method === 'POST' && proxy_req.body ){
        var url = "/zones/"+proxy_req.body.uuid+'/start';

        zones.put(url, function(err, req, res, obj){
            if( err ){
                proxy_res.status(500).send(err);
            }else{
                proxy_res.send(obj);
            }
        });
    }
});
app.post('/vms/stop', loadUser, function(proxy_req, proxy_res ){
    if( proxy_req.method === 'POST' && proxy_req.body ){
        var url = "/zones/"+proxy_req.body.uuid+'/stop';

        zones.put(url, function(err, req, res, obj){
            if( err ){
                proxy_res.status(500).send(err);
            }else{
                proxy_res.send(obj);
            }
        });
    }
});

app.post('/vms/create', loadUser, function(proxy_req, proxy_res ){
    if( proxy_req.method === 'POST' && proxy_req.body ){
        zones.post('/zones',
            {
                "alias" : proxy_req.body.alias,
                "os"    : proxy_req.body.os,
                "vcpus" : proxy_req.body.vcpus,
                "ram"   : proxy_req.body.ram

            }, function(err, req, res, obj) {
                if( !err && res.statusCode == 200 ){

                    User.findOneAndUpdate(
                        { username  : proxy_req.session.username},
                        { $push     : { vms : { uuid: obj.uuid }}},
                        function(err, model) {
                            if (err) {
                                proxy_res.status(500).send(err);
                            }else{
                                proxy_res.send( obj );
                            }
                        }
                    );
                }else{
                    proxy_res.status(500).send(err);
                }
            }
        );
    }
});
app.post('/vms/delete', loadUser, function(proxy_req, proxy_res){
    if( proxy_req.method === 'POST' && proxy_req.body ){
        var url = '/zones/'+proxy_req.body.uuid;
        zones.del(url,  function(err, req, res, obj){
            if( err ){
                proxy_res.status(500).send(err);
            }else {
                User.findOneAndUpdate(
                    { username  : proxy_req.session.username },
                    { $pull     : { vms : { uuid : proxy_req.body.uuid }}},
                    function(err, model){
                        if( err ){
                            proxy_res.status(500).send(err);
                        }else{
                            //proxy_res.send( obj );
                            proxy_res.send( obj );
                        }
                    });
            }
        });
    }
});
app.post('/vms/view', loadUser, function(proxy_req, proxy_res){
    if (proxy_req.method == 'POST' && proxy_req.body ) {

        var url = "/zones/"+proxy_req.body.uuid+'/spice';

        zones.get(url, function(err, req, res, obj){
            if( err ){
                proxy_res.status(500).send(err);
            }else{
                if( proxy_req.session.userport )
                    console.log(proxy_req.body.uuid,  proxy_req.session.userport, proxy_req.session.userport[''+proxy_req.body.uuid] );
                if( proxy_req.session.userport &&
                    proxy_req.session.userport[''+proxy_req.body.uuid] )
                {
                    proxy_res.render('spice', {port:proxy_req.session.userport[proxy_req.body.uuid].mongoport});
                }
                else
                {
                    portscan.findAPortNotInUse(27012, 27020, '127.0.0.1',
                        function (err, mongoport) {
                            if( !proxy_req.session.userport ) {
                                proxy_req.session.userport = {};
                            }
                            proxy_req.session.userport[proxy_req.body.uuid] = { spiceport : obj.spice_port, mongoport:mongoport };

                            var smartos = ' 192.168.0.2:';
                            var command = 'python /root/project/wes/run ' + mongoport + smartos + obj.spice_port;

                            console.log('cmd::', command);


                            var ps = exec(command);
                            proxy_res.render('spice', {port: mongoport});
                        });
                }
            }
        });
    }
});


//app.post run proxy








if (!module.parent) {
    http.createServer(app).listen(app.set('port'), function(){
        console.log('Express server listening on port ' + app.set('port'));
    });

    //console.log("Express server listening on port %d, environment: %s", app.address().port, app.settings.env)
}