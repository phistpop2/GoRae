package edu.gachon.check;

public class Check {
	
	// api key
	public static final String API_KEY_NAVER = "f85e6c36fdba85f75d084ad9f5e84809"; 
	
	// request url
	public static final String REQUEST_URL_NAVER="http://openapi.naver.com/search";
	public static final String REQUEST_PATH_NAVER = "openapi.naver.com/search";

}
