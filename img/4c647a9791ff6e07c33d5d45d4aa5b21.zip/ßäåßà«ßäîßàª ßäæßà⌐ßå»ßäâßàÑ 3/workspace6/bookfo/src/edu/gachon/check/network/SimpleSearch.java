package edu.gachon.check.network;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import android.util.Log;
import edu.gachon.check.Check;

public class SimpleSearch {
	
	
	
	public void search( String query){
		// simple search
		// key, target(book), query, display, start
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("key", Check.API_KEY_NAVER) );
		nameValuePairs.add(new BasicNameValuePair("target", "book") );
		nameValuePairs.add(new BasicNameValuePair("query", query) );
		nameValuePairs.add(new BasicNameValuePair("display", "10") );
		nameValuePairs.add(new BasicNameValuePair("start", "1") );
		
		AsyncRequest request = new AsyncRequest(Check.REQUEST_URL_NAVER, nameValuePairs){
			@Override
			protected void onPostExecute(List<BookItem> result) {
				searchResult( result );
				Log.d("okok", "onPost");
			}
		};
		request.execute();
	}
	protected void searchResult(List<BookItem> result){
		
	}

}
