package edu.gachon.check.activity;

import java.util.ArrayList;
import java.util.List;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import edu.gachon.check.R;
import edu.gachon.check.network.BookItem;
import edu.gachon.check.network.SimpleSearch;


public class MainActivity extends ActionBarActivity {
	private Button btnSearch;
	private EditText query;
	private ListView bookList;
	private BookAdapter adapter;
	private List<BookItem> items = new ArrayList<BookItem>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		adapter = new BookAdapter(this, R.layout.view_search_bookshelf, items);
		bookList = (ListView)findViewById(R.id.bookList);
		bookList.setAdapter( adapter );
		bookList.setDividerHeight(0);

		query = (EditText)findViewById(R.id.et_query);
		btnSearch = (Button)findViewById(R.id.btn_search);
		btnSearch.setOnClickListener( new OnClickListener(){
			@Override
			public void onClick(View v) {
				String input = query.getText().toString();
				if( input != null && input.length() > 0 ){
					new SimpleSearch(){
						@Override
						protected void searchResult(List<BookItem> result) {
							items.clear();
							items.addAll( result );
							adapter.notifyDataSetChanged();
						}
					}.search( input );
				}
			}
		});
		bookList.setOnItemClickListener( new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				DialogSimple();

			}
		});
	}
	private void DialogSimple(){
		AlertDialog.Builder alt_bld = new AlertDialog.Builder(this);
		alt_bld.setMessage("���� ���翡 �߰��Ͻðڽ���").setCancelable(
				false).setPositiveButton("��",
						new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						// Action for 'Yes' Button
						Toast.makeText( MainActivity.this, "server is not running :(", Toast.LENGTH_SHORT).show();

					}
				}).setNegativeButton("�ƴϿ�",
						new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						// Action for 'NO' Button
						Toast.makeText( MainActivity.this, "cancel", Toast.LENGTH_SHORT).show();
						dialog.cancel();
					}
				});
		AlertDialog alert = alt_bld.create();
		// Title for AlertDialog
		alert.setTitle("Title");
		// Icon for AlertDialog
		alert.show();
	}

}
