package edu.gachon.check.network;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.DefaultHttpClient;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import android.os.AsyncTask;
import android.util.Log;
import android.util.Xml;

public class AsyncRequest extends AsyncTask<Void, Void, List<BookItem>>{
	private String url;
	String ns = null;
	private ArrayList<NameValuePair> querys;



	public AsyncRequest( String url, ArrayList<NameValuePair> querys ){
		this.url = url;
		this.querys = querys;
	}

	@Override
	protected List<BookItem> doInBackground(Void... none) {
		ArrayList<BookItem> list = new ArrayList<BookItem>();
		try { 

			HttpClient client = new DefaultHttpClient();  
			String getURL = url+"?"+URLEncodedUtils.format(querys, "UTF-8");
			HttpGet get = new HttpGet(getURL);
			HttpResponse responseGet = client.execute(get);
			HttpEntity resEntityGet = responseGet.getEntity();


			InputStream in = resEntityGet.getContent();
			try {
				XmlPullParser parser = Xml.newPullParser();
				parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
				parser.setInput(in, null);
				parser.nextTag();
				list.addAll(readFeed(parser));
			} finally {
				in.close();
			}

			//tv_post.setText( EntityUtils.toString(resEntity));
		}catch(Exception e){e.printStackTrace();}
		return list;
	}
	private List readFeed(XmlPullParser parser) throws XmlPullParserException, IOException {
		List entries = new ArrayList();

		parser.require(XmlPullParser.START_TAG, ns, "rss");
		Log.d("okok", readText(parser) );
		//parser.require(XmlPullParser.START_TAG, ns, "channel");
		while (parser.next() != XmlPullParser.END_TAG) {
			if (parser.getEventType() != XmlPullParser.START_TAG) {
				continue;
			}
			String name = parser.getName();
			Log.d("okok", "name "+name);
			// Starts by looking for the entry tag
			if (name.equals("item")) {
				entries.add(readEntry(parser));
			} else {
				skip(parser);
			}
		}  
		//parser.require(XmlPullParser.END_TAG, ns, "rss");
		return entries;
	}


	// Parses the contents of an entry. If it encounters a title, summary, or link tag, hands them off
	// to their respective "read" methods for processing. Otherwise, skips the tag.
	private BookItem readEntry(XmlPullParser parser) throws XmlPullParserException, IOException {
		parser.require(XmlPullParser.START_TAG, ns, "item");

		HashMap<String, String> map = new HashMap<String, String>();

		while (parser.next() != XmlPullParser.END_TAG) {
			if (parser.getEventType() != XmlPullParser.START_TAG) {
				continue;
			}
			String name = parser.getName();
			if (name.equals("title")) {
				map.put("title", readTitle(parser));
			} else if (name.equals("link")) {
				map.put("link", readLink(parser));
			} else if (name.equals("image")) {
				map.put("image", readImageLink(parser));
			} else if (name.equals("author")) {
				map.put("author", readAuthor(parser));
			} else if (name.equals("price")) {
				map.put("price", readPrice(parser));
			} else if (name.equals("isbn")) {
				map.put("isbn", readISBN(parser));
			} else if (name.equals("publisher")) {
				map.put("publisher", readPublisher(parser));
			} else {
				// fix me!
				skip(parser);
			}
		}
		return new BookItem(map);
	}
	// Processes title tags in the feed.
	private String readTitle(XmlPullParser parser) throws IOException, XmlPullParserException {
		parser.require(XmlPullParser.START_TAG, ns, "title");
		String title = readText(parser);
		parser.require(XmlPullParser.END_TAG, ns, "title");
		return title;
	}

	// Processes title tags in the feed.
	private String readAuthor(XmlPullParser parser) throws IOException, XmlPullParserException {
		parser.require(XmlPullParser.START_TAG, ns, "author");
		String title = readText(parser);
		parser.require(XmlPullParser.END_TAG, ns, "author");
		return title;
	}
	// Processes title tags in the feed.
	private String readPrice(XmlPullParser parser) throws IOException, XmlPullParserException {
		parser.require(XmlPullParser.START_TAG, ns, "price");
		String title = readText(parser);
		parser.require(XmlPullParser.END_TAG, ns, "price");
		return title;
	}
	// Processes title tags in the feed.
	private String readISBN(XmlPullParser parser) throws IOException, XmlPullParserException {
		parser.require(XmlPullParser.START_TAG, ns, "isbn");
		String title = readText(parser);
		parser.require(XmlPullParser.END_TAG, ns, "isbn");
		return title;
	}
	// Processes title tags in the feed.
	private String readPublisher(XmlPullParser parser) throws IOException, XmlPullParserException {
		parser.require(XmlPullParser.START_TAG, ns, "publisher");
		String title = readText(parser);
		parser.require(XmlPullParser.END_TAG, ns, "publisher");
		return title;
	}

	// Processes link tags in the feed.
	private String readLink(XmlPullParser parser) throws IOException, XmlPullParserException {
		String link = "";
		parser.require(XmlPullParser.START_TAG, ns, "link");
		link = readText(parser);
		parser.require(XmlPullParser.END_TAG, ns, "link");
		return link;
	}
	// Processes link tags in the feed.
	private String readImageLink(XmlPullParser parser) throws IOException, XmlPullParserException {
		String link = "";
		parser.require(XmlPullParser.START_TAG, ns, "image");
		link = readText(parser);
		parser.require(XmlPullParser.END_TAG, ns, "image");
		return link;
	}

	// Processes summary tags in the feed.
	private String readSummary(XmlPullParser parser) throws IOException, XmlPullParserException {
		parser.require(XmlPullParser.START_TAG, ns, "summary");
		String summary = readText(parser);
		parser.require(XmlPullParser.END_TAG, ns, "summary");
		return summary;
	}

	// For the tags title and summary, extracts their text values.
	private String readText(XmlPullParser parser) throws IOException, XmlPullParserException {
		String result = "";
		if (parser.next() == XmlPullParser.TEXT) {
			result = parser.getText();
			parser.nextTag();
		}
		return result;
	}
	private void skip(XmlPullParser parser) throws XmlPullParserException, IOException {
		if (parser.getEventType() != XmlPullParser.START_TAG) {
			throw new IllegalStateException();
		}
		int depth = 1;
		while (depth != 0) {
			switch (parser.next()) {
			case XmlPullParser.END_TAG:
				depth--;
				break;
			case XmlPullParser.START_TAG:
				depth++;
				break;
			}
		}
	}


}
