package edu.gachon.check.network;

import java.util.HashMap;

public class BookItem {
	public final String title;
	public final String link;
	public final String image;
	public final String author;
	public final String price;
	public final String discount;
	public final String publisher;
	public final String pubdate;
	public final String isbn;
	public final String description;

	public BookItem(HashMap<String, String> map) {
		this.title = map.get("title");
		this.link = map.get("link");
		this.image = map.get("image");
		this.author = map.get("author");
		this.price = map.get("price");
		this.discount = map.get("discount");
		this.publisher = map.get("publisher");
		this.pubdate = map.get("pubdate");
		this.isbn = map.get("isbn");
		this.description = map.get("description");
	}
}
