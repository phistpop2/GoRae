package edu.gachon.check.activity;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import edu.gachon.check.R;
import edu.gachon.check.network.BookItem;
import edu.gachon.check.network.ImageDownloader;

public class BookAdapter extends BaseAdapter{

	private List<BookItem> items = null;

	private Context mContext;
	private LayoutInflater mInflater;
	private int mLayout;
	private ImageDownloader mImageDownloader;

	public BookAdapter(Context context, int layout, List list)
	{
		this.mContext = context;
		this.mLayout = layout;
		this.mInflater = (LayoutInflater) context.getSystemService
				(Context.LAYOUT_INFLATER_SERVICE);
		mImageDownloader = new ImageDownloader();
		items = list;
	}

	@Override
	public int getCount() {
		return items.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return items.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ShelfHolder viewHolder;
		 
	    // ĳ�õ� �䰡 ���� ��� ���� �����ϰ� ��Ȧ���� �����Ѵ�
	    if(convertView == null)
	    {
	        convertView = mInflater.inflate(mLayout, parent, false);
	 
	        viewHolder = new ShelfHolder();
	        viewHolder.img = (ImageView) convertView.findViewById(R.id.bookImage);
	        viewHolder.title = (TextView) convertView.findViewById(R.id.bookTitle);
	        viewHolder.author = (TextView) convertView.findViewById(R.id.bookAuthor);
	        viewHolder.price = (TextView) convertView.findViewById(R.id.bookPrice);
	        viewHolder.isbn = (TextView) convertView.findViewById(R.id.bookIsbn);
	 
	        convertView.setTag(viewHolder);
	    }
	    // ĳ�õ� �䰡 ���� ��� ����� ��Ȧ���� ����Ѵ�
	    else
	    {
	        viewHolder = (ShelfHolder) convertView.getTag();
	    }
	 
	    BookItem item = items.get(position);
	    
	    mImageDownloader.download( item.image, viewHolder.img);
        viewHolder.title.setText(Html.fromHtml(item.title));
        viewHolder.author.setText(item.author);
        viewHolder.price.setText(item.price);
        viewHolder.isbn.setText(item.isbn);
	 
	    return convertView;
	}
	

}
