package edu.gachon.check.activity;

import android.widget.ImageView;
import android.widget.TextView;

public class ShelfHolder {

	public ImageView img;
	public TextView title;
	public TextView price;
	public TextView author;
	public TextView isbn;
}
