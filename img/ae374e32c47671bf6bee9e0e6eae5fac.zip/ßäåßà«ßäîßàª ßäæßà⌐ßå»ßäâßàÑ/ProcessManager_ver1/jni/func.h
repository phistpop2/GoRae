// Common Helper Function
void do_swapint(int *tmpa, int *tmpb);
void do_swapptr(void **tmpa, void **tmpb);
