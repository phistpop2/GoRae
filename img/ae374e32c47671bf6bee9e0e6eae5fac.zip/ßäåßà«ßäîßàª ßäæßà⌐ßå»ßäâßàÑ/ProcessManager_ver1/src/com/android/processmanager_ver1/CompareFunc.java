package com.android.processmanager_ver1;

import java.lang.reflect.Method;

import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.preference.PreferenceActivity;

public class CompareFunc
{
	// SDK ��� ���� Ȯ���ϴ� �Լ�
	public static boolean checkExtraStore(PreferenceActivity activity)
	{
		boolean flag = false;
    	if(Integer.parseInt(Build.VERSION.SDK) >= 8)
    	{
    		// use Reflection to avoid errors (for cupcake 1.5)
    		Method MethodList[] = activity.getClass().getMethods();
    		for(int checkMethod = 0; checkMethod < MethodList.length; checkMethod++)
    		{
    			if(MethodList[checkMethod].getName().indexOf("ApplicationInfo") != -1)
    			{
    				try{
    					if((((ApplicationInfo) MethodList[checkMethod].invoke(activity , new Object[]{})).flags & 0x40000 /* ApplicationInfo.FLAG_EXTERNAL_STORAGE*/ ) != 0 )
    						flag = true;
    				}
    				catch(Exception e) {}
    			}
    		}
    	}
    	return flag;
	}
	
	// SDK ������ �������� �Լ�
	public static int getSDKVersion()
	{
		return Integer.parseInt(Build.VERSION.SDK);
	}
	
	// Screen Size�� Ȯ���ϴ� �Լ�
	private static int ScreenSize = 2; /* 0 == Small, 1 == Normal, 2 == Large */

	public static int getScreenSize()
	{
		return ScreenSize;
	}
	
	// Gesture Threshold
	public static final int SWIPE_MIN_DISTANCE = 120;
	public static final int SWIPE_MAX_OFF_PATH = 250;
	public static final int SWIPE_THRESHOLD_VELOCITY = 200;
}