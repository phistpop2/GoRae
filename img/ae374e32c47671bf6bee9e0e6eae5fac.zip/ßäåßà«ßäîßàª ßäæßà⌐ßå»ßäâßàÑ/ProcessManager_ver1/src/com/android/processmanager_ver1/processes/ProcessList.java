package com.android.processmanager_ver1.processes;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import android.os.Handler;
import android.util.Log;

import com.android.processmanager_ver1.JNIInterface;

public class ProcessList {
	private JNIInterface JNILibrary;

	// �߰� Data �ӽ� �������
	private String cpuUsage = null;
	private int processCounts = 0;
	private String memTotal = null;
	private String memFree = null;
	private HashMap<String, Integer> processStartCount = null;
	private HashMap<String, Boolean> processStartCheck = null;

	// memory ����� ���� ����
	private static DecimalFormat MemoryFormat = new DecimalFormat(",000");

	// data ��¥
	private int UpdateData = 2;

	// Sorting ���
	// 1. pid / 2. cpu / 3. memory / 4. threads / 5. name
	private int OrderBy = 1;

	// ���� Algorithm
	// 0 �ʰ� : quicksort / 0 ���� : bubblesort
	private int Algorithm = 1;

	// system process ���� ����
	private boolean ExcludeSystem = true;

	// 
	private boolean SortIn = false;

	// Root
	private static boolean Rooted = false;

	// freeze
	private static boolean FreezeIt = false;
	private static boolean FreezeTask = false;
	
	// ���μ��� ����Ƚ�� counting�� ���� thread
	Runnable storeDataRunnable = new Runnable() {
		@Override
		public void run() {
			Set<String> currentProcessList = new HashSet<String>();
			Set<String> beforeProcessList = processStartCheck.keySet();
			
			for(int i = 0 ; i < processCounts ; i++ )
			{
				String currentName = getProcessName(i); // ���� Ȯ���� ���μ����� �̸��� ������ ����
				
				// ������ ����Ǿ� �ִ� ���μ��� ��Ͽ� �ִ� ���
				if( processStartCheck.containsKey(currentName) )
				{
					// process ���� Ƚ���� �÷��ִ� �κ�
					if( !(processStartCheck.get(currentName)) )
					{
						processStartCheck.put(currentName, true);
						processStartCount.put(currentName, processStartCount.get(currentName)+1);
					}
				}
				else
				{
					processStartCheck.put(currentName, true);
					processStartCount.put(currentName, 1);
				}
				
				currentProcessList.add(currentName);
			}
			
			Iterator<String> itrBeforeProcessList = beforeProcessList.iterator();
			
			while( itrBeforeProcessList.hasNext() )
			{
				String tmpProcessName = itrBeforeProcessList.next();
				
				if( !(currentProcessList.contains(tmpProcessName)) )
				{
					processStartCheck.put(tmpProcessName, false);
				}
			}
			
			//Log.e("KC", processStartCount.toString());
			
			storeDataHandler.postDelayed(this, 5000);
		}
	};

	private Handler storeDataHandler = new Handler();
	
	// JNI data ������ ���� Thread
	private Runnable uiRunnable = new Runnable() {
		@Override
		public void run() {

			if (JNILibrary.doDataLoad() == 1) {
				cpuUsage = JNILibrary.GetCPUUsage();
				processCounts = JNILibrary.GetProcessCounts();
				memTotal = MemoryFormat.format(JNILibrary.GetMemTotal()) + "K";
				memFree = MemoryFormat.format(JNILibrary.GetMemBuffer()
						+ JNILibrary.GetMemCached() + JNILibrary.GetMemFree())
						+ "K";

				// process ���࿩�� ī��Ʈ�� ���� ����
				//storeDataHandler.post(storeDataRunnable);
				
				// ���࿩�� ������� - �ϴ� �� ����
				//onRefresh();
				Log.d( "okok", "process : "+processCounts);
				if ( processCounts > 0 ){
					Log.d("okok", "pid "+JNILibrary.GetProcessPID(0)+":"+JNILibrary.GetProcessName(0));
				}

			} else {
				if (FreezeIt) {
					if (!FreezeTask) {
						JNILibrary.doTaskStop();
						FreezeTask = true;
					} else
						cpuUsage = JNILibrary.GetCPUUsage();
				} else {
					if (FreezeTask) {
						JNILibrary.doTaskStart(JNILibrary.doTaskProcess);
						FreezeTask = false;
					}
				}

			}
			uiHandler.postDelayed(this, 50);
		}
	};

	private Handler uiHandler = new Handler();
	
	// ///////////////////////////////////////////////////////////////////////////////////////
	// ������
	public ProcessList() {
		processStartCount = new HashMap<String, Integer>();
		processStartCheck = new HashMap<String, Boolean>();
		
		JNILibrary = JNIInterface.getInstance();

		// JNI �۾� ����
		onResume();

		// �ش� device rooting ���� Ȯ��
		if (JNILibrary.GetRooted() == 1) {
			Rooted = true;
		}
	}

	// ///////////////////////////////////////////////////////////////////////////////////////
	// �� ���� Set �Լ���
	public void setUpdateData(int UpdateData) {
		this.UpdateData = UpdateData;
	}

	public void setOrderBy(int OrderBy) {
		this.OrderBy = OrderBy;
	}

	public void setAlgorithm(int Algorithm) {
		this.Algorithm = Algorithm;
	}

	public void setExcludeSystem(boolean ExcludeSystem) {
		this.ExcludeSystem = ExcludeSystem;
	}

	public void setSortIn(boolean SortIn) {
		this.SortIn = SortIn;
	}

	// ///////////////////////////////////////////////////////////////////////////////////////
	// JNI control fuctions

	private void restorePrefs() {
		// ??
		JNILibrary.doDataTime(UpdateData);

		// sort, algorithm ����
		JNILibrary.SetProcessSort(OrderBy);
		JNILibrary.SetProcessAlgorithm(Algorithm);

		// System Process ���Ÿ� ���ϴ� ��� true
		if (ExcludeSystem)
			JNILibrary.SetProcessFilter(1);
		else
			JNILibrary.SetProcessFilter(0);

		if (SortIn)
			JNILibrary.SetProcessOrder(0);
		else
			JNILibrary.SetProcessOrder(1);
	}

	// refresh
	public void onRefresh() {
		JNILibrary.doDataRefresh();
	}

	// JNI Stop
	public void onPause() {
		uiHandler.removeCallbacks(uiRunnable);
		JNILibrary.doTaskStop();
	}

	private void onResume() {
		restorePrefs();

		JNILibrary.doTaskStart(JNILibrary.doTaskProcess);
		
		// JNI �������� ����
		uiHandler.post(uiRunnable);
		
		// process ���࿩�� ī��Ʈ�� ���� ����
		//storeDataHandler.post(storeDataRunnable);
	}

	
	// ///////////////////////////////////////////////////////////////////////////////////////
	// �ʿ��� data get �Լ���
	// cpu
	public String getCPUUsage() // �ش� ����� CPU �� ��뷮
	{
		return cpuUsage;
	}
	
	public String getMemUsage() // �ش� ����� ������� memory �� ��뷮
	{
		return memTotal;
	}
	
	public String getMemFreeUsage() // �ش� ����� ���� memory �� ��뷮
	{
		return memFree;
	}

	public int getProcessCPUUsage(int position) // position�� �ִ� process�� cpu
												// usage
	{
		return JNILibrary.GetProcessLoad(position);
	}

	// process
	public int getProcessCounts() // process ����
	{
		return processCounts;
	}

	public String getProcessName(int position) // position�� �ִ� process�� name
	{
		return JNILibrary.GetProcessName(position);
	}

	public void killProcessPid(int pid) // pid�� �̿��Ͽ� �ش� process�� killl
	{
		if (Rooted) {
			String KillCmd = "";

			KillCmd += "kill -9 " + pid;

			JNILibrary.execCommand(KillCmd + "\n");
		} else {
			android.os.Process.killProcess(pid);
		}
	}

	public String getProcessMem(int position) // position�� �ִ� process�� �޸� ����
	{
		if (JNILibrary.GetProcessRSS(position) > 1024)
			return (JNILibrary.GetProcessRSS(position) / 1024) + "M";
		return JNILibrary.GetProcessRSS(position) + "K";
	}
}
