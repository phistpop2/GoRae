package com.ssm.monitor;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import edu.mit.media.funf.FunfManager;
import edu.mit.media.funf.json.IJsonObject;
import edu.mit.media.funf.pipeline.BasicPipeline;
import edu.mit.media.funf.pipeline.Pipeline;
import edu.mit.media.funf.probe.Probe.DataListener;
import edu.mit.media.funf.probe.builtin.AccelerometerSensorProbe;
import edu.mit.media.funf.probe.builtin.ActivityProbe;
import edu.mit.media.funf.probe.builtin.GravitySensorProbe;
import edu.mit.media.funf.probe.builtin.GyroscopeSensorProbe;
import edu.mit.media.funf.probe.builtin.LinearAccelerationSensorProbe;
import edu.mit.media.funf.probe.builtin.LocationAdvancedProbe;
import edu.mit.media.funf.probe.builtin.MagneticFieldSensorProbe;
import edu.mit.media.funf.probe.builtin.OrientationSensorProbe;
import edu.mit.media.funf.probe.builtin.ProcessStatisticsProbe;
import edu.mit.media.funf.probe.builtin.RotationVectorSensorProbe;
import edu.mit.media.funf.probe.builtin.WifiProbe;
import edu.mit.media.funf.storage.NameValueDatabaseHelper;


public class MainActivity extends ActionBarActivity implements DataListener {

	public static final String PIPELINE_NAME = "default";
	private FunfManager funfManager;
	private BasicPipeline pipeline;

	private WifiProbe wifiProbe;
	private ActivityProbe activityProbe;
	private LocationAdvancedProbe locationProbe;
	private ProcessStatisticsProbe runningAppProbe;

	private AccelerometerSensorProbe accelerometerSensorProbe;
	private GravitySensorProbe gravitySensorProbe;
	private GyroscopeSensorProbe gyroscopeSensorProbe;
	private LinearAccelerationSensorProbe linearAccelerationSensorProbe;
	private MagneticFieldSensorProbe magneticFieldSensorProbe;
	private OrientationSensorProbe orientationSensorProbe;
	private RotationVectorSensorProbe rotationVectorSensorProbe;

	private CheckBox enabledCheckbox;
	private Button archiveButton, scanNowButton, scanStopButton;
	private TextView dataCountView;
	private Handler handler;

	
	private TextView  accelValue;
	private TextView  gyroValue;
	private TextView nmeaValue;
	private TextView locationValue;




	private ServiceConnection funfManagerConn = new ServiceConnection() {    
		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			funfManager = ((FunfManager.LocalBinder)service).getManager();

			Gson gson = funfManager.getGson();

			wifiProbe = gson.fromJson(new JsonObject(), WifiProbe.class);
			locationProbe = gson.fromJson(new JsonObject(), LocationAdvancedProbe.class);
			activityProbe = gson.fromJson(new JsonObject(), ActivityProbe.class);
			runningAppProbe = gson.fromJson( new JsonObject(), ProcessStatisticsProbe.class);

			accelerometerSensorProbe = gson.fromJson(new JsonObject(), AccelerometerSensorProbe.class);
			gyroscopeSensorProbe = gson.fromJson(new JsonObject(), GyroscopeSensorProbe.class);

			pipeline = (BasicPipeline) funfManager.getRegisteredPipeline(PIPELINE_NAME);
			String testPipelineConfig = getResources().getString(R.string.default_pipeline);
			pipeline = (BasicPipeline) gson.fromJson(testPipelineConfig, Pipeline.class);
			pipeline.onCreate(funfManager);
			Log.d("okok", "probe "+pipeline);

			//wifiProbe.registerPassiveListener(MainActivity.this);
			locationProbe.registerPassiveListener(MainActivity.this);
			//activityProbe.registerPassiveListener(MainActivity.this);
			//runningAppProbe.registerPassiveListener(MainActivity.this);
			accelerometerSensorProbe.registerPassiveListener(MainActivity.this);
			gyroscopeSensorProbe.registerPassiveListener(MainActivity.this);
			

			// This checkbox enables or disables the pipeline
			enabledCheckbox.setChecked(pipeline.isEnabled());
			enabledCheckbox.setOnCheckedChangeListener(new OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if (funfManager != null) {
						if (isChecked) {
							funfManager.enablePipeline(PIPELINE_NAME);
							pipeline = (BasicPipeline) funfManager.getRegisteredPipeline(PIPELINE_NAME);
						} else {
							funfManager.disablePipeline(PIPELINE_NAME);
						}
					}
				}
			});

			// Set UI ready to use, by enabling buttons
			enabledCheckbox.setEnabled(true);
			archiveButton.setEnabled(true);
			scanNowButton.setEnabled(true);
			scanStopButton.setEnabled(true);
		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
			funfManager = null;
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		//ProcessList pl = new ProcessList();


		// Displays the count of rows in the data
		dataCountView = (TextView) findViewById(R.id.dataCountText);

		// Used to make interface changes on main thread
		handler = new Handler();

		enabledCheckbox = (CheckBox) findViewById(R.id.enabledCheckbox);
		enabledCheckbox.setEnabled(false);
		
		accelValue = (TextView)findViewById(R.id.accelValue);
		gyroValue = (TextView)findViewById(R.id.gyroValue);
		nmeaValue = (TextView)findViewById(R.id.nmeaValue);
		locationValue = (TextView)findViewById(R.id.locationValue);

		// Runs an archive if pipeline is enabled
		archiveButton = (Button) findViewById(R.id.archiveButton);
		archiveButton.setEnabled(false);
		archiveButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (pipeline.isEnabled()) {
					pipeline.onRun(BasicPipeline.ACTION_ARCHIVE, null);

					// Wait 1 second for archive to finish, then refresh the UI
					// (Note: this is kind of a hack since archiving is seamless and there are no messages when it occurs)
					handler.postDelayed(new Runnable() {
						@Override
						public void run() {
							Toast.makeText(getBaseContext(), "Archived!", Toast.LENGTH_SHORT).show();
							updateScanCount();
						}
					}, 1000L);
				} else {
					Toast.makeText(getBaseContext(), "Pipeline is not enabled.", Toast.LENGTH_SHORT).show();
				}
			}
		});
		// Forces the pipeline to scan now
		scanNowButton = (Button) findViewById(R.id.scanNowButton);
		scanNowButton.setEnabled(false);
		scanNowButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (pipeline.isEnabled()) {
					// Manually register the pipeline
					//wifiProbe.registerListener(pipeline);
					locationProbe.registerListener(pipeline);
					//activityProbe.registerListener(pipeline);
					//runningAppProbe.registerListener(pipeline);
					accelerometerSensorProbe.registerListener(pipeline);
					gyroscopeSensorProbe.registerListener(pipeline);
				} else {
					Toast.makeText(getBaseContext(), "Pipeline is not enabled.", Toast.LENGTH_SHORT).show();
				}
			}
		});

		scanStopButton = (Button)findViewById(R.id.scanStopButton);
		scanStopButton.setEnabled(false);
		scanStopButton.setOnClickListener( new OnClickListener(){
			@Override
			public void onClick(View v) {
				wifiProbe.unregisterListener(pipeline);
				locationProbe.unregisterListener(pipeline);
				activityProbe.unregisterListener(pipeline);
				runningAppProbe.unregisterListener(pipeline);
				accelerometerSensorProbe.unregisterListener(pipeline);
				gyroscopeSensorProbe.unregisterListener(pipeline);

				wifiProbe.unregisterPassiveListener(MainActivity.this);
				locationProbe.unregisterPassiveListener(MainActivity.this);
				activityProbe.unregisterPassiveListener(MainActivity.this);
				accelerometerSensorProbe.unregisterPassiveListener(MainActivity.this);
				gyroscopeSensorProbe.unregisterPassiveListener(MainActivity.this);
				updateScanCount();
			}

		});

		// Bind to the service, to create the connection with FunfManager
		bindService(new Intent(this, FunfManager.class), funfManagerConn, BIND_AUTO_CREATE);
	}
	private static final String TOTAL_COUNT_SQL = "SELECT count(*) FROM " + NameValueDatabaseHelper.DATA_TABLE.name;
	/**
	 * Queries the database of the pipeline to determine how many rows of data we have recorded so far.
	 */
	private void updateScanCount() {
		// Query the pipeline db for the count of rows in the data table
		SQLiteDatabase db = pipeline.getDb();
		Cursor mcursor = db.rawQuery(TOTAL_COUNT_SQL, null);
		mcursor.moveToFirst();
		final int count = mcursor.getInt(0);
		
		
		// Update interface on main thread
		runOnUiThread(new Runnable() {
			@Override
			public void run() {
				dataCountView.setText("Data Count: " + count);
			}
		});
	}

	@Override
	public void onDataReceived(IJsonObject probeConfig, final IJsonObject data) {

		Log.d("okok", "onData"+probeConfig);

		if( probeConfig.get("@type").equals( accelerometerSensorProbe.getConfig().get("@type"))){
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					accelValue.setText( "x : "+data.get("x")+", "+"y : "+data.get("y")+", "+"z : "+data.get("z"));
				}
			});
		}else if(probeConfig.get("@type").equals( gyroscopeSensorProbe.getConfig().get("@type"))){
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					gyroValue.setText( "x : "+data.get("x")+", "+"y : "+data.get("y")+", "+"z : "+data.get("z"));
				}
			});
		}else if(probeConfig.get("@type").equals(locationProbe.getConfig().get("@type"))){
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					if( data.has( "nmea") ){
						nmeaValue.setText( data.get("nmea").getAsString() );
					}else if( data.has("mAccuracy")){
						String r = "";
						r = r + "altitude:"+data.get("mAltitude");
						r = r+ ", lat:"+data.get("mLatitude");
						r = r+ ", lng:"+data.get("mLongitude");
						r = r+ ", provider"+data.get("mProvider");
						locationValue.setText( r );
					}
				}
			});
			
		}
		//Log.d("okko", "receive mem"+data.get("RUNNING_PROCESS_MEMORY_INFO"));
	}

	@Override
	public void onDataCompleted(IJsonObject probeConfig, JsonElement checkpoint) {
		updateScanCount();
		// Re-register to keep listening after probe completes.

		//wifiProbe.registerPassiveListener(this);
		locationProbe.registerPassiveListener(this);
		//activityProbe.registerPassiveListener(this);
		//runningAppProbe.registerPassiveListener(this);
		accelerometerSensorProbe.registerPassiveListener(this);
		gyroscopeSensorProbe.registerPassiveListener(this);
	}
}
